#!/usr/bin/python

import os,sys,time

x = "Reza Alfauzan"
y = "Ganteng"

def login():
        os.system("clear")
        os.system("figlet Access")
        logo = """
        \033[36;1m==============\033[35;1m===========================\033[36;1m==================
        \033[31;1m===  \033[36;1m[\033[33;1m*\033[36;1m] \033[32;1mAuthor : Reza Alfauzan                    \033[36;1m[\033[33;1m*\033[36;1m]  \033[31;1m===
        \033[31;1m===  \033[36;1m[\033[33;1m*\033[36;1m] \033[32;1mgithub : GRCR4K3R                         \033[36;1m[\033[33;1m*\033[36;1m]  \033[31;1m===
        \033[33;1m===  \033[36;1m[\033[33;1m*\033[36;1m] \033[32;1mUntuk Password Dan Usernamenya Kalian     \033[36;1m[\033[33;1m*\033[36;1m]  \033[33;1m===
        \033[31;1m===  \033[36;1m[\033[33;1m*\033[36;1m] \033[32;1mChat Saya Saja Di fb.com/reza123dcm       \033[36;1m[\033[33;1m*\033[36;1m]  \033[31;1m===
        \033[31;1m===  \033[36;1m[\033[33;1m*\033[36;1m] \033[32;1mJangan Recode Entar Error Bang            \033[36;1m[\033[33;1m*\033[36;1m]  \033[31;1m===
        \033[36;1m===========================================================
        \033[33;1m>~>~>~>~>~>~>~>~>~>~>\033[35;1m~~~~~~~~~~~~~~~~\033[33;1m<~<~<~<~<~<~<~<~<~<~<~"""
        
        print logo
        
        user = raw_input("Masukkan Usernamenya : ")
        pasw = raw_input("Masukkan Passwordnya : ")
        if user ==x and pasw ==y:
                print "Access Sukses!"
                time.sleep(1.5)
        else:
                print "Access Gagal:("
                time.sleep(1.5)
                os.system("python2 aneh.py")
if __name__ == "__main__":
        login()


def menu():
        os.system("clear")
        os.system("figlet Aneh?")
        print "\t \033[36;1mTools \033[35;1mBy \033[33;1mReza \033[32;1mAlfauzan\n"
        print("\033[36;1m1. Send Malware")
        print("\033[36;1m2. Ubah Tampilan")
        print("\033[36;1m3. Spam-no Work")
        print("\033[36;1m4. Perkalian")
        print("\033[36;1m5. Info Script")
        print("\033[36;1m6. Install Bahan BossQ!!(Wajib Untuk Jalanin Scriptnya)")
        print("\033[36;1m7. Send Virus(FAKE!!)")
        print("\033[36;1m8. Exit Borr")
        # input
        pilih = input("\033[35;1m==> \033[36;1mMasukkan \033[32;1mpilihan : ")
        if pilih ==1:
                os.system("clear")
                os.system("figlet Wait..")
                os.system("git clone https://github.com/GRCR4K3R/Marware")
        if pilih ==2:
                os.system("clear")
                os.system("figlet Wait..")
                os.system("git clone https://github.com/GRCR4K3R/Tampilan")
        if pilih ==3:
                os.system("clear")
                os.system("figlet Wait..")
                os.system("git clone https://github.com/GRCR4K3R/spam-pesan")
        if pilih ==4:
                os.system("clear")
                os.system("figlet Wait..")
                os.system("git clone https://github.com/GRCR4K3R/Perkalian")
        if pilih ==5:
                os.system("clear")
                os.system("figlet Info")
                logo = """
                \033[32;1m======================================================
                \033[32;1m=+=>(+) \033[36;1mAuthor : Reza Alfauzan                 \033[32;1m(+)<=+=
                \033[31;1m=+=>(+) \033[36;1mGithub : GRCR4K3R                      \033[34;1m(+)<=+=
                \033[36;1m=+=>(+) \033[32;1mJangan recode bang entar error         \033[36;1m(+)<=+=
                \033[36;1m=+=>(+) \033[36;1mMaaf Ya Gua masih noob:)               (+)<=+=
                ======================================================
                \033[36;1m**********************\033[32;1m*****************\033[36;1m***************"""
                print logo
                print"\t \033[36;1mTools \033[35;1mBy \033[33;1mReza \033[32;1mAlfauzan\n"
                time.sleep(3.5)
                os.system("python2 aneh.py")
        if pilih ==6:
                os.system("clear")
                os.system("figlet Tunggu / Wait")
                os.system("pkg update && pkg upgrade")
                os.system("clear")
                os.system("figlet Tunggu / Wait")
                os.system("pkg install nano")
                os.system("clear")
                os.system("figlet Tunggu / Wait")
                os.system("pkg install figlet")
                os.system("clear")
                os.system("figlet Tunggu / Wait")
                os.system("pkg install toilet")
                os.system("clear")
                os.system("figlet Tunggu / Wait")
                os.system("pkg install ruby")
                os.system("clear")
                os.system("figlet Tunggu / Wait")
                os.system("gem install lolcat")
                os.system("clear")
                os.system("figlet Tunggu / Wait")
                os.system("pkg install python")
                os.system("clear")
                os.system("figlet Tunggu / Wait")
                os.system("pip install requests")
                os.system("clear")
                os.system("figlet Tunggu / Wait")
                os.system("pip install mechanize")
                os.system("clear")
                os.system("figlet Tunggu / Wait")
                os.system("pip install futures")
                os.system("clear")
                os.system("figlet Tunggu / Wait")
                os.system("pip install --upgrade pip")
                os.system("clear")
                os.system("figlet Tunggu / Wait")
                os.system("pip2 install requests")
                os.system("clear")
                os.system("figlet Tunggu / Wait")
                os.system("pip2 install mechanize")
                os.system("clear")
                os.system("figlet Tunggu / Wait")
                os.system("pip2 install futures")
                os.system("clear")
                os.system("figlet Tunggu / Wait")
                os.system("pip2 install --upgrade pip")
                os.system("clear")
                os.system("figlet Sukses!")
                logo = """
                \033[32;1m======================================================
                \033[32;1m=+=>(+) \033[36;1mAuthor : Reza Alfauzan                 \033[32;1m(+)<=+=
                \033[31;1m=+=>(+) \033[36;1mGithub : GRCR4K3R                      \033[34;1m(+)<=+=
                \033[36;1m=+=>(+) \033[32;1mJangan recode bang entar error         \033[36;1m(+)<=+=
                \033[36;1m=+=>(+) \033[36;1mMaaf Ya Gua masih noob:)               (+)<=+=
                ======================================================
                \033[36;1m**********************\033[32;1m*****************\033[36;1m***************"""
                print logo
                print "\t \033[36;1mTools \033[35;1mBy \033[33;1mReza \033[32;1mAlfauzan\n"
        if pilih ==7:
                os.system("clear")
                os.system("figlet Sabar . .")
                os.system("git clone https://github.com/GRCR4K3R/VIRUS")
                os.system("cd VIRUS")
                os.system("ls")
                os.system("python2 virus.py")
        if pilih ==8:
                os.system("clear")
                os.system("figlet Byee")
                print "\t \033[36;1mSelamat \033[35;1mBerjumpa \033[33;1mLagi \033[32;1mKawan:)\n"
                print "\t \033[36;1mTools \033[35;1mBy \033[33;1mReza \033[32;1mAlfauzan\n"

menu()
