#!/bin/bash


clear
sleep 1
blue='\033[34;1m'
green='\033[32;1m'
purple='\033[35;1m'
cyan='\033[36;1m'
red='\033[31;1m'
white='\033[37;1m'
yellow='\033[33;1m'
toilet -f big -F gay Trojan Malware
blue='\033[34;1m'
green='\033[32;1m'
purple='\033[35;1m'
cyan='\033[36;1m'
red='\033[31;1m'
white='\033[37;1m'
yellow='\033[33;1m'
toilet -f big -F gay By Alfauzan-Xd
echo
sleep 1
echo -e $green"++++++++++++++++++++++++++++++++++++++++++++"
echo -e $cyan" Author : Reza Alfauzan-XD                  "
echo -e $purple" Youtube: Reja gaming                       "
echo -e $yellow" Pesan  : Namanya Juga Masih Bot:)          "
echo -e $green">         Welcome To My Script             <"
echo -e $red"++++++++++++++++++++++++++++++++++++++++++++"
echo
echo -e $cyan"1). SEND MALWARE"
echo -e $purple"2). SEND TROJANS"
echo
read -p "pilih => " virus
if [[ $virus == "1" ]]
then
read -p "Masukkan nomor target bro =>> " nomor
while [[ true ]]; do
echo "Send Malware ke $nomor Telah berhasil!"
done
fi
if [[ $virus == "2" ]]
then
read -p "Masukkan nomor target bro =>> " nomor2
while [[ true ]]; do
echo "Send Trojans ke $nomor2 Telah berhasil!"
done
fi
