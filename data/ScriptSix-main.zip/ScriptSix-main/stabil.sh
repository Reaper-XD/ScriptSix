clear
blue='\033[34;1m'
green='\033[32;1m'
purple='\033[35;1m'
cyan='\033[36;1m'
red='\033[31;1m'
white='\033[37;1m'
yellow='\033[33;1m'
sleep 1
echo
toilet -f big -F gay By Rzaa Ajaa
echo $purple"==============================="
echo $yellow"= (+) Author  : Reza Alfauzan ="
echo $green"= (+) Youtube : Reja gaming   ="
echo $yellow"= (+) Facebook: Rzaa Aja      ="
echo $green"==============================="
echo $red"Welcome Brother!"
echo
sleep 2
echo $green"Pilih saja toolsnya : "
echo
echo $cyan"1.)Stabilkan jaringan"
echo
echo $cyan"2.)Keluar/Exit."
echo
echo $green
read -p "PilihMana : " bro
if [ $bro = 1 ] || [ $bro = 1 ]
then
clear
toilet -f big -F gay Rzaa Ajaa
toilet -f big -F gay By Reza Alfauzan
echo $cyan "Sedang Mengstabilkan../Mohon Menunggu.."
sleep 2
ping -s1000 1.1.1.1
fi

if [ $bro = 2 ] || [ $bro = 2 ]
then
clear
echo $yellow
figlet "Good Bye!"
echo $red"To be Continued"
sleep 3
exit
fi
