# Script Kon...
<code><pre>
$pkg install python2
$pkg install git
$git clone https://github.com/Reaper-XD/ScriptSix
Oke Itu Udah Siap Scriptnya
</code></pre>
# Run Script
<pre><code>
$cd ScriptSix
$ls
$python2 All.py
Sudah Siap
</pre></code>
Oke Usernamenya Chat Gua Di https://www.facebook.com/reza123dcm/
