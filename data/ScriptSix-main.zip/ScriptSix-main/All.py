#!/usr/bin/python

import os,sys,time

x = "Reaper-XD"
y = "Reza Gans"

#mengetik Otomatis
def auto(z):
        for e in z + "\n":
                sys.stdout.write(e)
                sys.stdout.flush()
                time.sleep(0.02)

def login():
        os.system("clear")
        os.system("toilet -f big -F gay Access User")
        time.sleep(2.5)
        logo = """
        \033[36;1m==============\033[35;1m[\033[33;1m*\033[35;1m] \033[33;1mSilahkan Login Bro \033[35;1m[\033[33;1m*\033[35;1m]\033[36;1m===================
        \033[36;1m================\033[35;1m=========================\033[36;1m==================
        \033[31;1m===  \033[36;1m[\033[33;1m*\033[36;1m] \033[32;1mAuthor : Reza Alfauzan                    \033[36;1m[\033[33;1m*\033[36;1m]  \033[31;1m===
        \033[31;1m===  \033[36;1m[\033[33;1m*\033[36;1m] \033[32;1mgithub : Reaper-XD                        \033[36;1m[\033[33;1m*\033[36;1m]  \033[31;1m===
        \033[33;1m===  \033[36;1m[\033[33;1m*\033[36;1m] \033[32;1mUntuk Password Dan Usernamenya Kalian     \033[36;1m[\033[33;1m*\033[36;1m]  \033[33;1m===
        \033[31;1m===  \033[36;1m[\033[33;1m*\033[36;1m] \033[32;1mChat Saya Saja Di fb.com/reza123dcm       \033[36;1m[\033[33;1m*\033[36;1m]  \033[31;1m===
        \033[31;1m===  \033[36;1m[\033[33;1m*\033[36;1m] \033[32;1mJangan Recode Entar Error Bang            \033[36;1m[\033[33;1m*\033[36;1m]  \033[31;1m===
        \033[36;1m===========================================================
        \033[33;1m>~>~>~>~>~>~>~>~>~>~>\033[35;1m~~~~~~~~~~~~~~~~\033[33;1m<~<~<~<~<~<~<~<~<~<~<~
        \033[36;1m<\033[35;1m===================\033[33;1m[ \033[31;1mSilahkan Login \033[33;1m]\033[35;1m====================\033[36;1m>"""
        
        print logo
        time.sleep(2.0)
        
        user = raw_input("\033[33;1mM\033[31;1ma\033[36;1ms\033[35;1mu\033[32;1mk\033[34;1mk\033[33;1ma\033[31;1mn \033[33;1mU\033[31;1ms\033[36;1me\033[35;1mr\033[32;1mn\033[34;1ma\033[34;1mm\033[33;1me\033[36;1mn\033[35;1my\033[32;1ma : ")
        pasw = raw_input("\033[33;1mM\033[37;1ma\033[31;1ms\033[36;1mu\033[35;1mk\033[32;1mk\033[34;1ma\033[33;1mn \033[37;1mP\033[31;1ma\033[36;1ms\033[35;1ms\033[32;1mw\033[34;1mo\033[33;1mr\033[37;1md\033[31;1mn\033[36;1my\033[35;1ma : ")
        if user ==x and pasw ==y:
                auto("\033[33;1mA\033[31;1mc\033[36;1mc\033[35;1me\033[32;1ms\033[34;1ms \033[35;1mS\033[33;1mu\033[31;1mk\033[36;1ms\033[35;1me\033[33;1ms!")
                time.sleep(1.5)
        else:
                auto("\033[33;1mA\033[31;1mc\033[36;1mc\033[35;1me\033[32;1ms\033[34;1ms\033[35;1mG\033[33;1ma\033[31;1mg\033[36;1m\033[35;1ma\033[33;1ml:(")
                time.sleep(1.5)
                os.system("python2 All.py")
if __name__ == "__main__":
        login()


def menu():
        os.system("clear")
        os.system("toilet -f big -F gay Tools XD")
        time.sleep(2.5)
        logo = """
        \033[36;1m============\033[35;1m[\033[33;1m*\033[35;1m] \033[33;1mSilahkan Pilih Scriptnya \033[35;1m[\033[33;1m*\033[35;1m]\033[36;1m===============
        \033[36;1m================\033[35;1m=========================\033[36;1m==================
        \033[31;1m===  \033[36;1m[\033[33;1m*\033[36;1m] \033[32;1mAuthor \033[36;1m: \033[33;1mReza Alfauzan                    \033[36;1m[\033[33;1m*\033[36;1m]  \033[31;1m===
        \033[31;1m===  \033[36;1m[\033[33;1m*\033[36;1m] \033[32;1mgithub \033[36;1m: \033[33;1mReaper-XD                        \033[36;1m[\033[33;1m*\033[36;1m]  \033[31;1m===
        \033[33;1m===  \033[36;1m[\033[33;1m*\033[36;1m] \033[32;1mPesan  \033[36;1m: \033[33;1mReza Ganteng Gak?                \033[36;1m[\033[33;1m*\033[36;1m]  \033[33;1m===
        \033[31;1m===  \033[36;1m[\033[33;1m*\033[36;1m] \033[32;1mFB     \033[36;1m: \033[33;1mRzaa Aja                         \033[36;1m[\033[33;1m*\033[36;1m]  \033[31;1m===
        \033[31;1m===  \033[36;1m[\033[33;1m*\033[36;1m] \033[32;1mJangan \033[33;1mRecode Entar Error Bang            \033[36;1m[\033[33;1m*\033[36;1m]  \033[31;1m===
        \033[36;1m===========================================================
        \033[33;1m>~>~>~>~>~>~>~>~>~>~>\033[35;1m~~~~~~~~~~~~~~~~\033[33;1m<~<~<~<~<~<~<~<~<~<~<~
        \033[36;1m<\033[35;1m===================\033[33;1m[ \033[31;1mSilahkan Pilih \033[33;1m]\033[35;1m====================\033[36;1m>"""
        
        print logo
        print "\t \033[36;1mTools \033[35;1mBy \033[33;1mReza \033[32;1mAlfauzan\n"
        print("\033[35;1m1. \033[36;1mSend \033[32;1mMalware")
        print("\033[34;1m2. \033[33;1mUbah \033[31;1mTampilan")
        print("\033[32;1m3. \033[34;1mSpam-no \033[33;1mWork")
        print("\033[33;1m4. \033[31;1mPerkalian")
        print("\033[34;1m5. \033[33;1mHack \033[31;1mFacebook")
        print("\033[31;1m6. \033[36;1mInstall \033[35;1mBahan \033[32;1mBossQ!!\033[36;1m(Wajib Untuk Jalanin Scriptnya)")
        print("\033[35;1m7. \033[32;1mSend \033[34;1mVirus\033[36;1m(FAKE!!)")
        print("\033[36;1m8. \033[35;1mExit \033[33;1mBorr")
        # input
        pilih = input("\033[35;1mMasukkan \033[32;1mpilihan \033[33;1m==> : ")
        if pilih ==1:
                os.system("clear")
                os.system("figlet Wait..")
                os.system("git clone https://github.com/Reaper-XD/Marware")
        if pilih ==2:
                os.system("clear")
                os.system("figlet Wait..")
                os.system("git clone https://github.com/Reaper-XD/Tampilan")
        if pilih ==3:
                os.system("clear")
                os.system("figlet Wait..")
                os.system("git clone https://github.com/Reaper-XD/spam-pesan")
        if pilih ==4:
                os.system("clear")
                os.system("figlet Wait..")
                os.system("git clone https://github.com/Reaper-XD/Perkalian")
        if pilih ==5:
                os.system("clear")
                os.system("toilet -f big -F gay Access User")
                logo = """
                \033[36;1m================\033[35;1m[\033[33;1m*\033[35;1m] \033[33;1mSelamat Datang!! \033[35;1m[\033[33;1m*\033[35;1m]\033[36;1m===================
                \033[36;1m================\033[35;1m=========================\033[36;1m==================
                \033[31;1m===  \033[36;1m[\033[33;1m*\033[36;1m] \033[32;1mAuthor \033[36;1m: \033[33;1mReza Alfauzan                    \033[36;1m[\033[33;1m*\033[36;1m]  \033[31;1m===
                \033[31;1m===  \033[36;1m[\033[33;1m*\033[36;1m] \033[32;1mgithub \033[36;1m: \033[33;1mReaper-XD                        \033[36;1m[\033[33;1m*\033[36;1m]  \033[31;1m===
                \033[33;1m===  \033[36;1m[\033[33;1m*\033[36;1m] \033[32;1mUntuk Password Dan Usernamenya Kalian     \033[36;1m[\033[33;1m*\033[36;1m]  \033[33;1m===
                \033[31;1m===  \033[36;1m[\033[33;1m*\033[36;1m] \033[32;1mChat Saya Saja Di fb.com/reza123dcm       \033[36;1m[\033[33;1m*\033[36;1m]  \033[31;1m===
                \033[31;1m===  \033[36;1m[\033[33;1m*\033[36;1m] \033[32;1mJangan Recode Entar Error Bang            \033[36;1m[\033[33;1m*\033[36;1m]  \033[31;1m===
                \033[36;1m===========================================================
                \033[33;1m>~>~>~>~>~>~>~>~>~>~>\033[35;1m~~~~~~~~~~~~~~~~\033[33;1m<~<~<~<~<~<~<~<~<~<~<~
                \033[36;1m<\033[35;1m===================\033[33;1m[ \033[31;1mSilahkan Masuk \033[33;1m]\033[35;1m====================\033[36;1m>"""
          
                print logo
                time.sleep(2.5)
                print "\t \033[36;1mTools \033[35;1mBy \033[33;1mReza \033[32;1mAlfauzan\n"
                time.sleep(2.5)
                os.system("python2 brute.py")
        if pilih ==6:
                os.system("clear")
                os.system("figlet Tunggu / Wait")
                os.system("pkg update && pkg upgrade")
                os.system("clear")
                os.system("figlet Tunggu / Wait")
                os.system("pkg install nano")
                os.system("clear")
                os.system("figlet Tunggu / Wait")
                os.system("pkg install figlet")
                os.system("clear")
                os.system("figlet Tunggu / Wait")
                os.system("pkg install toilet")
                os.system("clear")
                os.system("figlet Tunggu / Wait")
                os.system("pkg install ruby")
                os.system("clear")
                os.system("figlet Tunggu / Wait")
                os.system("gem install lolcat")
                os.system("clear")
                os.system("figlet Tunggu / Wait")
                os.system("pkg install python")
                os.system("clear")
                os.system("figlet Tunggu / Wait")
                os.system("pip install requests")
                os.system("clear")
                os.system("figlet Tunggu / Wait")
                os.system("pip install mechanize")
                os.system("clear")
                os.system("figlet Tunggu / Wait")
                os.system("pip install futures")
                os.system("clear")
                os.system("figlet Tunggu / Wait")
                os.system("pip install --upgrade pip")
                os.system("clear")
                os.system("figlet Tunggu / Wait")
                os.system("pip2 install requests")
                os.system("clear")
                os.system("figlet Tunggu / Wait")
                os.system("pip2 install mechanize")
                os.system("clear")
                os.system("figlet Tunggu / Wait")
                os.system("pip2 install futures")
                os.system("clear")
                os.system("figlet Tunggu / Wait")
                os.system("pip2 install --upgrade pip")
                os.system("clear")
                os.system("figlet Sukses!")
                logo = """
                \033[32;1m======================================================
                \033[32;1m=+=>(+) \033[36;1mAuthor : Reza Alfauzan                 \033[32;1m(+)<=+=
                \033[31;1m=+=>(+) \033[36;1mGithub : Reaper-XD                     \033[34;1m(+)<=+=
                \033[36;1m=+=>(+) \033[32;1mJangan recode bang entar error         \033[36;1m(+)<=+=
                \033[36;1m=+=>(+) \033[36;1mMaaf Ya Gua masih noob:)               (+)<=+=
                ======================================================
                \033[36;1m**********************\033[32;1m*****************\033[36;1m***************"""
                print logo
                print "\t \033[36;1mTools \033[35;1mBy \033[33;1mReza \033[32;1mAlfauzan\n"
        if pilih ==7:
                os.system("clear")
                os.system("figlet Sabar . .")
                os.system("git clone https://github.com/Reaper-XD/VIRUS")
        if pilih ==8:
                os.system("clear")
                os.system("figlet Byee")
                print "\t \033[36;1mSelamat \033[35;1mBerjumpa \033[33;1mLagi \033[32;1mKawan:)\n"
                print "\t \033[36;1mTools \033[35;1mBy \033[33;1mReza \033[32;1mAlfauzan\n"
                time.sleep(3.0)
                os.system("exit")

                
menu()
